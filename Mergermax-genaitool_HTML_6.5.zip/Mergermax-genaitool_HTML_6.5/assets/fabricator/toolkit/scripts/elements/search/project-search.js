import {
    addClassToElement,
    addEventListener,
    elementHasClass,
    getHtmlElmentsByClass,
    removeClassFromElement,
    getQueryHtmlElements,
  } from "../../ui-scripts";
  
  export const addFilter = () => {
    let filter = document.getElementById('project-filter');
    if (filter) {
      filter.addEventListener('click', () => {
        let block = document.getElementById('filter-blck');
        if (elementHasClass(block, "-active")) {
          block.className = 'c-project-search__filterblock';
        } else {
          addClassToElement(block, '-active')
        }
      });
    }
  
    const overlay = document.querySelector(".c-projects-cont__overlay");
    const fltr = document.querySelector(".c-project-search .-stagemap");
    const mapFilter = document.getElementById('mapfilter');
    if (mapFilter) {
      mapFilter.addEventListener('click', () => {
        let block = document.getElementById('map-filter');
        if (elementHasClass(block, "-active")) {
          block.className = 'c-project-search__filterblock';
          removeClassFromElement(overlay, "-open");
        } else {
          addClassToElement(block, '-active')
          addClassToElement(overlay, "-open");
        }
      });
    }
  }
  
  window.addFilter = addFilter;
  