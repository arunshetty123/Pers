import {
  getElementById,
  addEventListener,
  elementHasClass,
  addClassToElement,
  removeClassFromElement,
  getChildElements,
  getHtmlElmentsByClass,
} from "../../ui-scripts";

import BaseClass from "../../utils/base-class";
import Context from "../../utils/context";
import { setFocusToFirstItem, getKeyboardFocusableElements } from "../../utils/utilities";

const COMPONENT_KEY = 'selectInput';

class SelectInput extends BaseClass {

  constructor(element) {
    super(element);

    if (!this._element) return;
    // console.log('fr', this._element.id)
    this._inputElement = this._element.firstElementChild;
    this._inputOptions = this._element.lastElementChild;
    this._onSelect = (label, value) => {};

    this._watchClick_var = this._watchClickOutside.bind(this);    
    this._focusableChildren = getKeyboardFocusableElements(this._inputOptions);
    this._clickHandler = this._handleClick.bind(this);
    this._optionsClickHandler = this._handleOptionsClick.bind(this);
    this._keyboardHandler = this._handleKeys.bind(this);

    this._init();
  }

  // Getter
  static get COMPONENT_KEY() {
    return COMPONENT_KEY;
  }

  _showOptions() {
    addClassToElement(this._inputElement, "-active");
    addClassToElement(this._inputOptions, "-active");
    
    // setFocusToFirstItem(this.inputOptions);
    this._inputElement.setAttribute('aria-expanded','true');
    // this._focusableChildren.forEach((item)=>{
    //   item.setAttribute('tabindex','0');
    // })
    this._element.addEventListener('keydown',this._keyboardHandler);
    document.addEventListener("click", this._watchClick_var, true);
  }

  _hideOptions() {
    removeClassFromElement(this._inputElement, "-active");
    removeClassFromElement(this._inputOptions, "-active");
    
    this._inputElement.setAttribute('aria-expanded','false');
    // this._focusableChildren.forEach((item)=>{
    //   item.setAttribute('tabindex','-1');
    // })
    this._element.removeEventListener('keydown',this._keyboardHandler);
    document.removeEventListener("click", this._watchClick_var, true);
  }


  _handleKeys(event){
    this._focusableChildren = getKeyboardFocusableElements(this._inputOptions);
    let totalItems = this._focusableChildren.length - 1 || null;
    if (!totalItems) return;
    if (!this._inputOptions.classList.contains('-active')) return;
    if(event.type != 'keydown') return;

    if (event.key === 'Tab' || event.key === 'Escape') {
      this._hideOptions();
      this._inputElement.focus();
      return;
    }

    if(event.key == 'ArrowUp' || event.key == 'ArrowDown') {
      event.preventDefault();
      event.stopPropagation();
    }

    let activeIndex = this._focusableChildren.indexOf(event.target);

    if (event.key === 'ArrowUp') activeIndex--;
    if (event.key === 'ArrowDown') activeIndex++;

    activeIndex = activeIndex > totalItems ? 0 : activeIndex;
    activeIndex = activeIndex < 0 ? totalItems : activeIndex;

    this._focusableChildren[activeIndex].focus();
  }

  _watchClickOutside(event) {
    if ((event.target != this._inputElement) && (event.target != this._inputOptions) && !this._inputElement.contains(event.target) && !this._inputOptions.contains(event.target)) {
      this._hideOptions();
    }
  }

  _addValueToInput(valueLabel) {
    addClassToElement(this._inputElement, "-input");
    this._inputElement.innerText = valueLabel;
  }

  _onElementClick() {
    addEventListener(this._inputElement, "click", this._clickHandler );
    // addEventListener(this._inputElement, "keyup", this._clickHandler );
  }
  _handleClick(event){
    if(event.type == 'keyup' && event.keyCode!==13) return;

    if (!elementHasClass(this._inputElement, "-active")) { this._showOptions(); } 
    else { this._hideOptions(); }
  }

  _onOptionsClick() {
    const options = getChildElements(this._inputOptions);
    options.map((option) => {
      addEventListener(option, "click", this._optionsClickHandler);
      // addEventListener(option, "keyup", this._optionsClickHandler);
    });
  }
  _handleOptionsClick(event){
    if(event.type == 'keyup' && event.keyCode!==13) return;

    let option = event.currentTarget;
    let parentClass = option.closest('.c-select');
    let childOptions = Array.from( parentClass.querySelectorAll('.c-select__option') ) || [];
    if(parentClass.querySelector('.c-select__option.-selected')){
      parentClass.querySelector('.c-select__option.-selected').classList.remove('-selected');
    }
    option.classList.add('-selected');

    let label = option.innerText;
    let value = option.getAttribute("data-value");
    this._addValueToInput(label);
    this._inputElement.focus();
    this._onSelect(label, value);
    this._hideOptions();
    
  }

  _init() {
    this._onElementClick();
    this._onOptionsClick();

    this._element.addEventListener('data.refreshed',()=>{
      this._onOptionsClick();
    })
  }

  /** Static Interface to check for an existing instance, create new if required and return the Instance
     * @param {*} element:HTMLElement - will be bound to _element property on the instance 
     * @returns class instance with parameter bound to _element
     */
  static selectInterface(element) {
    let context = Context.get(element, COMPONENT_KEY);
    if(context){
      return context;
    }
    if (!context) { 
      return new SelectInput(element); 
    }
  }
}

export const selectElement = () =>{
  if(!document.querySelector('.c-select')){
      return;
  }

  // NOTE: CALL THIS ON ngAfterViewInit()
  let select_elements = [].slice.call(document.querySelectorAll('.c-select')) || [];
  let elements = select_elements.map(item => SelectInput.selectInterface(item));
}