import {
    getQueryHtmlElements,
    addEventListener,
    elementHasClass,
    addClassToElement,
    removeClassFromElement,
} from "../../ui-scripts";
 

const show_class = "-active"; // Active class for dropdown
let listeners = {}; //JS object to keep track of document.body eventlisteners

export const multiselectTwoElement = () => {
  const selectedArrows = getQueryHtmlElements(".o-multi-select-two__arrow");
 
  selectedArrows.map((arrow) => {
    addEventListener(arrow, "click", () => {
      if(elementHasClass(arrow, show_class)) close_multiselect(arrow);
      else open_multiselect(arrow);
    });
  });
};
 
/**
 * Open the dropdown
 * @param {*} arrow:HTMLElement (Event Target)
 */
function open_multiselect(arrow) {
    const parent = arrow.parentElement;
    const dropdown = parent.nextElementSibling;
    addClassToElement(dropdown, show_class);
    addClassToElement(parent, show_class);
    addClassToElement(arrow, show_class);

    const watchout_listener = watchClickOutside.bind(null, arrow);
    listeners[arrow] = watchout_listener;
    document.addEventListener("click", watchout_listener, true);
}

/**
 * Close the dropdown
 * @param {*} arrow:HTMLElement (Event Target)
 */
function close_multiselect(arrow) {
    const parent = arrow.parentElement;
    const dropdown = parent.nextElementSibling;
    removeClassFromElement(dropdown, show_class);
    removeClassFromElement(parent, show_class);
    removeClassFromElement(arrow, show_class);

    const watchout_listener = listeners[arrow];
    document.removeEventListener("click", watchout_listener, true);
    delete listeners[arrow];
}

/**
 * Watch for click events outside of the dropdown and close it as necessary
 * @param {*} arrow:HTMLElement (Arrow element present in the dropdown)
 * @param {*} event:Event
 */
function watchClickOutside(...args) { //arrow, event is also an option
    const arrow = args[0];
    console.log(args, arrow);
    const parent = arrow.parentElement;
    const dropdown = parent.nextElementSibling;
    const event = args.pop();

    // If the event target is not the multiselect or it's descendents, close the dropdown
    if ((event.target != parent) && (event.target != dropdown) && !parent.contains(event.target) && !dropdown.contains(event.target)) {
        close_multiselect(arrow);
    }
}