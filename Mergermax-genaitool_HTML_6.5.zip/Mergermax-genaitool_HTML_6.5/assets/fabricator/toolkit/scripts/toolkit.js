/* ==============================================================================
Index
----------------------------------------
01 - Imports
02 - 
03 - 
04 - 
05 -
06 -
07 -
08 -
09 -
============================================================================== */

/* 01 - Imports */
// global elements
import { Switch, switchINIT } from "./elements/toggles/switch"; // Switch
import { ToggleSwitch, toggleINIT } from "./elements/toggles/toggleswitch"; // Toggle
import { RangeSlider, rangeSliderINIT } from "./elements/inputs/rangeslider"; // Input Rangeslider

//toolkit elements
import { selectElement } from "./elements/inputs/select";
import { vtoggle__switch } from "./elements/toggles/verticalToggle";
import { addFilter } from "./elements/search/project-search";
import { multiselectTwoElement } from "./elements/inputs/multi-select-two.js";

// global components
import { Dropdown , dropdownComponent} from './components/layout/dropdown'; // Dropdown
import { Tabs, tabsComponent } from "./components/layout/tabs"; //Tabs
import { Collapse, collapseComponent } from "./components/layout/accordion"; //Accordion / Collapse
import { Slideinpanel, slideinpanelINIT } from "./components/layout/slideinpanel";
import { Flyout, flyoutComponent } from "./components/layout/flyout"; //Flyout
import { Tooltip, tooltipFunc } from "./components/layout/tooltip"; //Tooltip
import { Popover, popoverFunc } from "./components/layout/popover"; //Popover
import { Carousel, carouselINIT } from "./components/layout/carousel"; //Carousel
import { Modal, modalComponent } from "./components/modals/modal"; //Modal
import { Adcarousel, adCarouselINIT } from "./components/layout/adcarousel"; //Carousel - 2
import { ComboboxAutocomplete, comboboxINIT } from "./components/layout/comboBox"; //Combobox
import {dataRequestTable} from "./components/data-request-table";
import {promtDropdown, browsePrompts, ChatcontentTable, followupPrompts, inputsuggestPrompts, filesuggestPrompts} from "./components/layout/chat-bot"
import {stickyChatBot} from "./components/layout/stickyChatBot"
import {generateReport} from "./components/genrate-report";
import {userguideMenu} from "./components/cards/user-guide-card.js";
// toolkit components
import { myspValueProposition } from "./components/miscellaneous/tree-chart";

//02- Function calls
// call global/common elements 
toggleINIT();
rangeSliderINIT();
switchINIT();
dataRequestTable();

// call toolkit/app relevant elements here
selectElement();
vtoggle__switch();
addFilter();
multiselectTwoElement();

// call global/common components
dropdownComponent();
tooltipFunc();
tabsComponent();
carouselINIT();
slideinpanelINIT();
adCarouselINIT();
modalComponent();
collapseComponent();
popoverFunc();
flyoutComponent();
comboboxINIT();
stickyChatBot();
promtDropdown();
// app relevant components
myspValueProposition();
generateReport();
userguideMenu();
browsePrompts();
followupPrompts();
ChatcontentTable();
inputsuggestPrompts();
filesuggestPrompts();

export default {

}
