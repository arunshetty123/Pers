export const dataRequestTable = () => {

    document.addEventListener('DOMContentLoaded', function () {
        var gapsAcc = document.querySelectorAll('.data-req');
        
        gapsAcc.forEach(function (acc) {
            acc.addEventListener('click', function () {
                // Toggle the visibility of the next tr with class request-Data
                var requestData = this.closest('tr').nextElementSibling;
                var rowItem = this.closest('tr').querySelectorAll('td');
                rowItem.forEach(function(item) {
                    item.classList.toggle('-active');
                })
                toggleVisibility(requestData);
                var arrowIcon = this.querySelector('.icon-caret');
                arrowIcon.classList.toggle('rotated');
            });
        });

        function toggleVisibility(element) {
            if (element.style.display === 'none' || element.style.display === '') {
                element.style.display = 'table-row';
            } else {
                element.style.display = 'none';
            }
        }
    });

    document.addEventListener('DOMContentLoaded', function () {
        const readMoreLink = document.querySelector('.read-more');
        const readLessLink = document.querySelector('.read-less');
        const extraPoints = document.querySelectorAll('.extra');
        const readMoreContainer = document.querySelector('.read-more-container');
        const readLessContainer = document.querySelector('.read-less-container');
  
        
        readMoreLink && readMoreLink.addEventListener('click', function (e) {
          e.preventDefault();
          extraPoints.forEach(point => point.style.display = 'list-item');
          readMoreContainer.style.display = 'none';
          readLessContainer.style.display = 'block';
        });

        readLessLink && readLessLink.addEventListener('click', function (e) {
          e.preventDefault();
          extraPoints.forEach(point => point.style.display = 'none');
          readMoreContainer.style.display = 'inline';
          readLessContainer.style.display = 'none';
        });
      });
}
