export const generateReport = () => {
    const mainbtn = document.querySelectorAll(
        ".-popup-wrapper .c-generate-report-sidebar__details"
    );
    mainbtn.forEach((x) => {
        x.addEventListener("click", () => {
            if (!x.classList.contains("-active")) {
                x.classList.add('-active');
                if(document.querySelector('.c-executive-summary')) {
                    x.closest(".-popup-wrapper").querySelector(".c-executive-summary").classList.add("-active");
                }
                if(document.querySelector(".c-generate-report-sidebar")) {
                    x.closest(".-popup-wrapper").querySelector(".c-generate-report-sidebar").classList.add("-close-side-bar");
                }
                if(document.querySelector('.c-report-table')) {
                    x.closest(".-popup-wrapper").querySelector(".c-report-table").classList.add("-active");
                }
            } else {
                x.classList.remove('-active');
                if(document.querySelector(".c-generate-report-sidebar")) {
                    x.closest(".-popup-wrapper").querySelector(".c-generate-report-sidebar").classList.remove("-close-side-bar");
                }
                if(document.querySelector('.c-executive-summary')) {
                    x.closest(".-popup-wrapper").querySelector(".c-executive-summary").classList.remove("-active");
                }
                if(document.querySelector('.c-report-table')) {
                    x.closest(".-popup-wrapper").querySelector(".c-report-table").classList.remove("-active");
                }
            }
        });
    });
}