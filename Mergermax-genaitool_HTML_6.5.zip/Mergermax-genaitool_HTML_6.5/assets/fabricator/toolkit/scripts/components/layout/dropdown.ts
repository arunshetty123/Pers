/* Dropdown */

import * as Popper from '@popperjs/core';

import {
  isElementDisabled,
  setFocusToFirstItem
} from '../../utils/utilities';
import Context from '../../utils/context';
import BaseClass from '../../utils/base-class';

const COMPONENT_KEY:string = 'dropdown';
const OPEN_CLASS:string = '-open';

export class Dropdown extends BaseClass {
  _parent:HTMLElement;
  _dropdown:any;
  _firstMenuitem:boolean;
  _lastMenuitem:boolean;
  _popper:any;
  _selectableOptions:HTMLElement[];

  _watchClick_var:EventListener = this._watchClickOutside.bind(this);    
  _itemClickEvHandler:EventListener = this._itemClickHandler.bind(this);
  _dropdownToggleEvHandler:EventListener = this._dropdownToggle.bind(this);
  _dropdownRefreshEv:EventListener = this._refreshDropdown.bind(this);
  _menuKeyHandlerEv:EventListener = this._menuKeyHandler.bind(this);

  constructor(element:HTMLElement) {
    super(element);

    this._parent = this._element.closest('.c-dropdown');
    this._dropdown = this._getDropdownElement();
    this._firstMenuitem = false;
    this._lastMenuitem = false;
    this._popper = null;
    this._selectableOptions = [].slice.call(this._dropdown.querySelectorAll('.-dismiss-dropdown, a.c-dropdown-item:not(:disabled):not(.disabled), button.c-dropdown-item:not(:disabled):not(.disabled), .-selectable.c-dropdown-item:not(label):not(:disabled):not(.disabled)')) || [];

    if (this._parent && this._dropdown) this._init();
  }
  
  // Getter
  static get COMPONENT_KEY() {
    return COMPONENT_KEY;
  }

  // 1.1 - Initialize Object and add eventlisteners
  _init() {
    this._dropdown = this._getDropdownElement();
    this._element.setAttribute('aria-haspopup', 'true');

    this._element.addEventListener('click', this._dropdownToggleEvHandler);
    this._selectableOptions.forEach((item:any)=>{
      item.addEventListener('click',this._itemClickEvHandler);
    })
    this._element.addEventListener('keydown', this._menuKeyHandlerEv);
    this._dropdown.addEventListener('keydown', this._menuKeyHandlerEv);
    this._parent.addEventListener('hide.dropdown', this._dropdownToggleEvHandler);
    this._parent.addEventListener('data.refreshed', this._dropdownRefreshEv);
  }

  // 1.2 - Destroy object instance and remove eventlisteners
  _dispose() {
    this._dropdown = null;

    if (this._popper) {
      this._popper.destroy();
      this._popper = null;
    }

    this._element.removeEventListener('click', this._dropdownToggleEvHandler);
    this._element.removeEventListener('keydown', this._menuKeyHandlerEv);
    this._dropdown.removeEventListener('keydown', this._menuKeyHandlerEv);
    this._selectableOptions.forEach((item:any)=>{
      item.removeEventListener('click',this._itemClickEvHandler);
    })
    this._parent.removeEventListener('hide.dropdown', this._dropdownToggleEvHandler);
    this._parent.removeEventListener('data.refreshed', this._dropdownRefreshEv);

    super.dispose();
  }

  // 2.1 - Show dropdown
  _show() {
    if (this._isDisabled()) return;
    
    this._element.setAttribute('aria-expanded', 'true');
    this._parent.classList.add(OPEN_CLASS);
    this._element.focus({preventScroll:true, focusVisible:true});

    // fire showing event
    this._parent.dispatchEvent(new Event('data.dropdown.showing',{bubbles: true}));

    if (typeof Popper === 'undefined') {
      throw new TypeError('Dropmenu require Popper (https://popper.js.org)');
    }

    // positioning the dropmenu using popper utility
    const isPlacementRight = this._parent.classList.contains('-right');
    const isPlacementStatic = this._parent.classList.contains('-static');
    const isPositionFixed = this._parent.classList.contains('-body');

    this._popper = Popper.createPopper(this._element, this._dropdown, {
      placement: isPlacementRight ? 'bottom-end' : 'bottom-start',
      strategy: isPositionFixed ? 'fixed' : 'absolute',
      modifiers: [
        { name: 'preventOverflow', options: { altAxis: true, boundary: 'clippingParents' } },
        { name: 'flip', options: { fallbackPlacements: isPlacementRight ? ['top-end', 'bottom-end'] : ['top-start', 'bottom-start'] } },
        { name: 'offset', options: { offset: [0, 0] } },
        { name: 'applyStyles', enabled: !isPlacementStatic }
      ]
    });

    if (isPlacementRight) this._popper.forceUpdate();

    // fire shown event
    this._parent.dispatchEvent(new Event('data.dropdown.shown',{bubbles: true}));

    this._refreshDropdown();
    document.addEventListener("click", this._watchClick_var, true);
  }

  /**
   * 2.2 - Hide dropdown (Sets focus back to _element by default unless specified otherwise)
   * @param flag : boolean
   */
  _hide(flag:boolean=true) {
    if (this._isDisabled()) return;

    if (this._isOpen()) {
      this._element.setAttribute('aria-expanded', 'false');
      this._parent.classList.remove(OPEN_CLASS);
      // this._parent.setAttribute('role','');

      // fire closing event
      this._parent.dispatchEvent(new Event('data.dropdown.closing',{bubbles: true}));

      // destroy popper instance
      if (this._popper) this._popper.destroy();

      // this._parent.dispatchEvent(new Event('drop.myw.close'));
      flag && this._element.focus({preventScroll:true, focusVisible:true});
    }

    // this._refreshDropdown();
    document.removeEventListener("click", this._watchClick_var, true);

    // fire closed event
    this._parent.dispatchEvent(new Event('data.dropdown.closed',{bubbles: true}));
  }

  // 2.3 - Toggle show and hide
  toggle() {
    if (this._isDisabled()) return;

    if (this._isOpen()) {
      this._hide();
    } else {
      this._show();
    }
  }

  /**
   * 3.1 - While dropdown is open, watch for clicks outside of it and close the dropdown. (Focus isn't set back to _element)
   * @param event : Event
   */
  _watchClickOutside(event:Event) {
    // console.log(event, event.target, this._dropdown, this)
    if ((event.target != this._element) && (event.target != this._dropdown) && !this._dropdown.contains(event.target)) {
      this._hide(false);
    }
  }  

  /**
   * 3.2 - Handle keyboard actions on the dropdown
   * @param event 
   */
  _menuKeyHandler(event:any) {
    const isActive:any = this._isOpen();

    // if( (event.target == this._element || this._element.contains(event.target)) && (event.key == 'Enter') && !isActive) {  return; } //!ISaCTIVE IS OPTIONAL
    if( !(event.key==='Tab' || event.key==='Escape' || event.key==='Enter' || event.key==='ArrowUp' || event.key==='ArrowDown' || event.key === 'Space' || event.key === ' ') ) return;
    if(isActive && (event.key === 'Space' || event.key === ' ')) return;

    const menuitems:any = [].slice.call(this._dropdown.querySelectorAll('a:not(:disabled):not(.disabled), input:not(:disabled):not(.disabled), button:not(:disabled):not(.disabled), .-selectable:not(:disabled):not(.disabled)')) || [];
    if (!isActive && event.key === 'Tab') return;

    if (isActive && event.key === 'Tab') {
      this._hide();
      // this._element.focus({preventScroll:true, focusVisible:true});
      return;
    }

    if( (event.key === 'ArrowUp' || event.key === 'ArrowDown')){
      event.preventDefault();
      event.stopPropagation();
    }

    if (this._isDisabled()){ 
      return; 
    }

    if (event.key === 'Escape') {
      this._hide();
      // this._element.focus({preventScroll:true, focusVisible:true});
      return;
    }
    if (!isActive && (event.key === 'ArrowUp' || event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ')) {
      this._show();
      if (!menuitems.length) return;
      (event.key === 'ArrowUp') ? menuitems[menuitems.length - 1].focus() : menuitems[0].focus();
      return;
    }

    if (isActive && (event.key === 'Enter' && event.target === this._element) || (event.key === 'Tab')) {
      this._hide();
      // this._element.focus({preventScroll:true, focusVisible:true});
      return;
    }

    if(isActive && (event.key === 'ArrowDown')) {
      menuitems[0].focus();
    }
    if (!menuitems.length) return;

    let targetEl:any = event.target;
    // if(event.target.type == "checkbox" || event.target.type == "radio"){
    //   targetEl = event.target.closest('label');
    // }
    let menuitemIndex = menuitems.indexOf(targetEl);

    if (event.key === 'ArrowUp') menuitemIndex--;

    if (event.key === 'ArrowDown') menuitemIndex++;

    menuitemIndex = (event.key === 'ArrowUp' && menuitemIndex < 0) ? menuitems.length - 1 : menuitemIndex;

    menuitemIndex = (event.key === 'ArrowDown' && menuitemIndex > menuitems.length - 1) ? 0 : menuitemIndex;
  
    menuitems[menuitemIndex].focus();
    
  }

   /**
   * 3.3 - Method to call toggle via js (bound to hide.dropdown event)
   * @param event : Event
   */
  _dropdownToggle(event:Event){
    event.preventDefault();
    this.toggle();
  }

  // 3.4
  _refreshDropdown(){
    this._selectableOptions.forEach((item:any)=>{
      item.removeEventListener('click',this._itemClickEvHandler);
    })

    this._selectableOptions = [].slice.call(this._dropdown.querySelectorAll('.-dismiss-dropdown, a.c-dropdown-item:not(:disabled):not(.disabled), button.c-dropdown-item:not(:disabled):not(.disabled), .-selectable.c-dropdown-item:not(label):not(:disabled):not(.disabled)')) || [];
    this._selectableOptions.forEach((item:any)=>{
      item.addEventListener('click',this._itemClickEvHandler);
    })
  }

  /**
   * 3.5 - Close dropdown when an option is selected (checkbox, label, radio elements, input fields are exempt)
   * @param event : Event
   */
  _itemClickHandler(event:any){
    if((event.currentTarget.tagName == 'A' || event.currentTarget.tagName == 'BUTTON') && this._isOpen() ){
      this._hide();
    }
    return;
    if(event.target.type == "checkbox" || event.target.type == "radio"){
      return;
    }
    this._hide();
  }

 

  // Utils
  _getDropdownElement() {
    if (!this._parent) return null;
    return this._parent.querySelector('.c-dropdown-menu') || null;
  }

  _isOpen() {
    return this._element.getAttribute('aria-expanded') === 'true' && this._parent.classList.contains(OPEN_CLASS);
  }

  _isDisabled() {
    return isElementDisabled(this._element) || false;
  }

  _getMenuElement() {
    return this._parent.querySelector('.c-dropdown-menu') || null;
  }

  
  /** Static Interface to check for an existing instance, create new if required and return the Instance
     * @param {*} element:HTMLElement - will be bound to _element property on the instance 
     * @returns class instance with parameter bound to _element
     */
  static dropdownInterface(element:HTMLElement) {
    const context:any = Context.get(element, COMPONENT_KEY);
    if (!context) {
      return new Dropdown(element);
    }
    return context;
    // if(context){ return context; }
    // if(!context){ return new Dropdown(element); }
  }
}

export const dropdownComponent = () => {
  if(!(document.querySelector('.c-dropdown'))) return;

  const dropdownComponents:any = [].slice.call(document.querySelectorAll('.c-dropdown > [aria-expanded]') as NodeListOf<HTMLElement>) || [];
  const dropdowns:any = dropdownComponents.map((item:HTMLElement)=>Dropdown.dropdownInterface(item));
};