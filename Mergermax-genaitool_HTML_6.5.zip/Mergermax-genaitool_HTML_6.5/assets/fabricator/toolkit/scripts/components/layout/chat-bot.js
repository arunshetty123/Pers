export const promtDropdown = () => {
    //dropdown one
    const mainbtn = document.querySelectorAll(
        ".-popup-wrapper .c-chat-bot-dropdown__promt-library"
    );
    mainbtn.forEach((x) => {
        x.addEventListener("click", () => {
            if (!x.classList.contains("-active")) {
                x.classList.add("-active");
                x.closest(".-popup-wrapper").querySelector(".c-chat-bot-dropdown__dropdown-promt-lib").classList.add("-active");
                x.closest(".-popup-wrapper").querySelector(".c-chat-bot-dropdown__dropdown-promt-lib-drop").classList.remove("-active");
                x.closest(".-popup-wrapper").querySelector(".c-chat-bot-dropdown__dropdown-two").classList.remove("-active");
            } else {
                x.classList.remove("-active");
                x.closest(".-popup-wrapper").querySelector(".c-chat-bot-dropdown__dropdown-promt-lib").classList.remove("-active");
            }
        });
    });

    //dropdown two
    const dropdownTwo = document.querySelectorAll(
        ".-popup-wrapper .c-chat-bot-dropdown__dropdown-two"
    );
    dropdownTwo.forEach((x) => {
        x.addEventListener("click", () => {
            if (!x.classList.contains("-active")) {
                x.classList.add("-active");
                x.closest(".-popup-wrapper").querySelector(".c-chat-bot-dropdown__dropdown-promt-lib-drop").classList.add("-active");
                x.closest(".-popup-wrapper").querySelector(".c-chat-bot-dropdown__dropdown-promt-lib").classList.remove("-active");
                x.closest(".-popup-wrapper").querySelector(".c-chat-bot-dropdown__promt-library").classList.remove("-active");

            } else {
                x.classList.remove("-active");
                x.closest(".-popup-wrapper").querySelector(".c-chat-bot-dropdown__dropdown-promt-lib-drop").classList.remove("-active");
            }
        });
    });


    //chat-bot expand for full screen
    const mainbtnExpand = document.querySelectorAll(
        ".-popup-wrapper .c-chat-bot__expand-icon"
    );

    mainbtnExpand.forEach((x) => {
        x.addEventListener("click", () => {
            if (!x.classList.contains("-active")) {
                x.classList.add("-active");
                x.closest(".-popup-wrapper").querySelector(".c-stickyChatBot__container").classList.add('container');
                x.closest(".-popup-wrapper").querySelector(".c-stickyChatBot-expand").classList.add("-active");
                x.classList.remove('icon-expand');
                x.classList.add("icon-minimize")
            } else {
                x.classList.remove("-active");
                x.closest(".-popup-wrapper").querySelector(".c-stickyChatBot__container").classList.remove('container')
                x.closest(".-popup-wrapper").querySelector(".c-stickyChatBot-expand").classList.remove("-active");
                x.classList.add('icon-expand');
                x.classList.remove("icon-minimize")
            }
        });
    });
};
export const browsePrompts = () => {
    const browseLink = document.querySelector('.c-chat-bot__comment.-browselink') || null;
    const browseContainer = document.querySelector('.c-chat-bot__footer-prompt-menu.-browsePrompt') || null;
    const browseClose = document.querySelector('.-browsePrompt .c-chat-bot__footer-prompt-header-close') || null;
    const followuopContainer = document.querySelector('.c-chat-bot__footer-Prompt-menu.-follow-up-Prompt') || null;

    if (browseLink != null && followuopContainer != null) {
        browseLink.addEventListener('click', () => {
            browseContainer.classList.add('-open');
            followuopContainer.classList.remove('-open');
        })
        browseClose.addEventListener('click', () => {
            browseContainer.classList.remove('-open');
        })
    }
}
export const followupPrompts = () => {
    const followupLink = document.querySelector('.c-chat-bot__footer-generic-links-items.-follow-up-link') || null;
    const followupContainer = document.querySelector('.c-chat-bot__footer-prompt-menu.-follow-up-Prompt') || null;
    const browseClose = document.querySelector('.-follow-up-Prompt .c-chat-bot__footer-prompt-header-close') || null;
    const followuppromptContainer = document.querySelector('.c-chat-bot__footer-Prompt-menu.-browsePrompt') || null;

    if (followupLink != null) {
        followupLink.addEventListener('click', () => {
            followupContainer.classList.add('-open');
            if (followuppromptContainer != null) {
                followuppromptContainer.classList.remove('-open');
            }
        })
        browseClose.addEventListener('click', () => {
            followupContainer.classList.remove('-open');
        })
    }
}
export const ChatcontentTable = () => {
    document.addEventListener('DOMContentLoaded', function () {

        const tableContainer = document.querySelector('.c-chat-bot__chat-content-table');

        if (!tableContainer) return;

        const editIcon = document.querySelector('.edit-icon');
        const editButton = tableContainer.querySelector('.editIconBtn');
        const closeButton = tableContainer.querySelector('.closeIconBtn');
        const completeButton = tableContainer.querySelector('.completeBtn');
        const afterEdit = tableContainer.querySelector('.afterEdit');
        const tableColmns = tableContainer.querySelectorAll('th') || [];

        let isEditing = false;

        editButton.addEventListener('click', function (event) {
            event.stopPropagation();
            tableContainer.classList.add('focused');
            afterEdit.classList.add('-show');
            editIcon.classList.remove('-show');
        });

        closeButton.addEventListener('click', function (event) {
            tableContainer.classList.remove('focused');
            afterEdit.classList.remove('-show');
            // editIcon.classList.show('-show');
        });

        completeButton.addEventListener('click', () => {
            tableContainer.classList.remove('focused');
            afterEdit.classList.remove('-show');
            // editIcon.classList.show('-show');
        });

        if (tableColmns.length != 0) {
            tableColmns.forEach(el => {
                const td = tableContainer.querySelectorAll(`td`) || [];
                el.addEventListener('mouseleave', () => {
                    td.forEach(item => {
                        item.classList.remove('column');
                    })
                })
                el.addEventListener('mouseenter', () => {
                    const colValue = el.getAttribute('data-col');
                    const tableBodyColumns = tableContainer.querySelectorAll(`td[data-col="${colValue}"]`) || [];
                    tableBodyColumns.forEach((item) => {
                        item.classList.add('column');
                    })
                })
            });
        }
    });
}
export const inputsuggestPrompts = () => {
    document.addEventListener('DOMContentLoaded', function () {
        const inputsuggestLink = document.querySelector('.o-input-custom__input.-input-suggest-link') || null;
        const inputsuggestContainer = document.querySelector('.c-chat-bot__footer-prompt-menu.-input-prompt') || null;

        if (inputsuggestLink != null) {
            inputsuggestLink.addEventListener("keypress", function (event) {
                if (event.key === '/') {
                    // console.log("Hello world!");
                    inputsuggestContainer.classList.add('-open');
                }
            });
            document.addEventListener("click", (event) => {
                const filesuggestContainer = document.querySelector('.c-chat-bot__footer-prompt-menu.-file-prompt') || null;
                const inputsuggestContainer = document.querySelector('.c-chat-bot__footer-prompt-menu.-input-prompt') || null;

                if ((event.target != filesuggestContainer) && (event.target != inputsuggestContainer)) {
                    inputsuggestContainer.classList.remove('-open');
                }
            }, true);
        }
    })
}
export const filesuggestPrompts = () => {
    const filesuggestLink = document.querySelector('.-input-prompt .c-chat-bot__footer-prompt-suggest-header .-file-suggested-upload') || null;
    const filesuggestContainer = document.querySelector('.c-chat-bot__footer-prompt-menu.-file-prompt') || null;
    const filesSuggestClose = document.querySelector('.-file-prompt .c-chat-bot__footer-prompt-suggest-header .-backtoprevious') || null;
    const inputsuggestContainer = document.querySelector('.c-chat-bot__footer-prompt-menu.-input-prompt') || null;

    if (filesuggestLink != null) {
        filesuggestLink.addEventListener('click', () => {
            filesuggestContainer.classList.add('-show');
            inputsuggestContainer.classList.remove('-open');
        })
        filesSuggestClose.addEventListener('click', () => {
            filesuggestContainer.classList.remove('-show');
            inputsuggestContainer.classList.add('-open');
        })
    }
}
