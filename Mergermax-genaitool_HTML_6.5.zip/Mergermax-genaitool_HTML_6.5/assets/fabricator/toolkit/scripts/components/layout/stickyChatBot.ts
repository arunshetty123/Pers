export const stickyChatBot = () => {
    const chatBot_Link = document.querySelector(".c-stickyChatBot-button") || null;
    const chatBot_Container = document.querySelector(".c-stickyChatBot-expand") || null;
    const parentCont = chatBot_Container && chatBot_Container.parentElement || null;
    const chatBot_Close = chatBot_Container && chatBot_Container.querySelector(".c-chat-bot__closeBtn") || null;
    const mainbtn = document.querySelectorAll(
        ".c-stickyChatBot-button"
    );
    const close = document.querySelectorAll(".c-chat-bot__closeBtn") || null;

    mainbtn.forEach((x) => {
        x.addEventListener("click", () => {
            if (!x.classList.contains("-expanded")) {
                x.closest(".-popup-wrapper").querySelector(".c-stickyChatBot").classList.add("-expanded");
            } else {
                x.closest(".-popup-wrapper").querySelector(".c-stickyChatBot").classList.remove("-expanded");
            }
        });
    });
    close.forEach((close) => {
        close.addEventListener("click", () => {
            close.closest(".-popup-wrapper").querySelector(".c-stickyChatBot").classList.remove("-expanded");
        });
    });
    // if(chatBot_Link != null) {
    //     chatBot_Link.addEventListener('click',()=>{
    //         parentCont.classList.add("-expanded");
    //     })
    // }

    // if(chatBot_Close !=null) {
    //     chatBot_Close.addEventListener('click',()=>{
    //         parentCont.classList.remove('-expanded');
    //     })
    // }
}