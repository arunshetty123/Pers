export const userguideMenu = () => {
document.addEventListener('DOMContentLoaded', () => {
    const menuIcon = document.querySelector('.c-user-guide-card__clickicon');
    const textViewWrap = document.querySelector('.c-user-guide-card__clickview-wrap');

    if(menuIcon !=null) {
        menuIcon.addEventListener('click', (event) => {
            event.stopPropagation(); 
           
            textViewWrap.style.display = textViewWrap.style.display === 'block' ? 'none' : 'block';
        });
    
        
        document.addEventListener('click', (event) => {
            if (!menuIcon.contains(event.target) && !textViewWrap.contains(event.target)) {
                textViewWrap.style.display = 'none';
            }
        });
    }
});
};