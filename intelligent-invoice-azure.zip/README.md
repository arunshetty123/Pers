# Intelligent Invoice Agent (Microservices) - Azure OpenAI Edition

This repository contains two microservices:
- **orchestrator/** : LangChain + LangGraph orchestration using Azure OpenAI
- **gateway/**     : FastAPI gateway that UiPath calls

Setup:
1. Copy .env.example in each service and set AZURE_OPENAI_* variables.
2. Install dependencies: pip install -r requirements.txt (each service)
3. Build FAISS index (optional) and run services with uvicorn or docker-compose.
