from loguru import logger
import os, sys
os.makedirs('logs', exist_ok=True)
logger.remove()
logger.add(sys.stderr, level='INFO', format='{time:HH:mm:ss} | {level} | {message}')
logger.add('logs/gateway.log', rotation='2 MB')
