from fastapi import FastAPI
from pydantic import BaseModel
from langgraph.engine import Node, GraphExecutor
from langgraph import nodes as lg_nodes
from core.logger import logger

app = FastAPI(title='Orchestrator - Azure OpenAI')

class InvoiceRequest(BaseModel):
    invoice_text: str = None
    invoice_path: str = None

@app.post('/process_invoice')
def process_invoice(payload: InvoiceRequest):
    initial = payload.dict()
    nodes = [
        Node('OCR', lg_nodes.ocr_node),
        Node('EXTRACT', lg_nodes.extract_node),
        Node('RAG', lg_nodes.rag_node),
        Node('VALIDATE', lg_nodes.validation_node),
        Node('REASON', lg_nodes.reasoner_node),
        Node('DECIDE', lg_nodes.decision_node)
    ]
    edges = [
        ('OCR','EXTRACT'),
        ('EXTRACT','RAG'),
        ('EXTRACT','VALIDATE'),
        ('RAG','REASON'),
        ('VALIDATE','REASON'),
        ('REASON','DECIDE')
    ]
    executor = GraphExecutor(nodes, edges)
    ctx = executor.run(initial)
    return {
        'invoice_id': ctx.get('invoice_id'),
        'final_status': ctx.get('final_status'),
        'issues': ctx.get('issues'),
        'ai_reasoning': ctx.get('ai_reasoning'),
        'policies_context': ctx.get('policies_context')
    }

@app.get('/')
def root():
    return {'message':'Orchestrator (Azure OpenAI) running'}
