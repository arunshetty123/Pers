        import pandas as pd
from core.logger import logger

class Validator:
    def __init__(self, vendor_csv='data/vendor_master.csv'):
        self.df = pd.read_csv(vendor_csv)

    def check(self, vendor_name, po_number, amount):
        issues = []
        if not vendor_name or not po_number:
            issues.append('Missing vendor or PO.')
            return issues
        match = self.df[(self.df['vendor_name'].str.lower() == str(vendor_name).lower()) & (self.df['po_number'].str.upper() == str(po_number).upper())]
        if match.empty:
            issues.append('Vendor/PO not found in vendor master.')
        else:
            cap = float(match.iloc[0]['max_amount'])
            if amount is not None and amount > cap:
                issues.append(f'Amount {amount} exceeds cap {cap}.')
            if str(match.iloc[0].get('sensitive', False)).lower() in ('true','1','yes'):
                issues.append('Vendor marked sensitive — KYC required.')
        logger.info('Validation issues: %s', issues)
        return issues
