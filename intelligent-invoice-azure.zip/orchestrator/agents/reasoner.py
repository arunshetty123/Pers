        import json
from langchain.schema import HumanMessage
from langchain.chat_models import AzureChatOpenAI
from core.config import settings
from core.logger import logger

class Reasoner:
    def __init__(self, deployment_name=None):
        self.deployment = deployment_name or settings.AZURE_OPENAI_DEPLOYMENT
        self.llm = AzureChatOpenAI(deployment_name=self.deployment, openai_api_base=settings.AZURE_OPENAI_ENDPOINT, openai_api_key=settings.AZURE_OPENAI_API_KEY, temperature=0.0)

    def reason(self, invoice: dict, issues: list, policies_context: str):
        prompt = f"""You are an invoice reasoning assistant. Return strict JSON:\n- status: 'Valid'|'Needs Review'|'Rejected'\n- reasoning: short explanation\n- suggested_action: string\n\nInvoice: {invoice}\nIssues: {issues}\nPolicies: {policies_context}\n"""
        try:
            resp = self.llm([HumanMessage(content=prompt)])
            content = resp.content
        except Exception as e:
            logger.error('LLM call failed: %s', e)
            return {'status':'Needs Review','reasoning':'LLM failure','suggested_action':'Manual review'}
        try:
            return json.loads(content)
        except Exception:
            return {'status':'Needs Review','reasoning':content[:800],'suggested_action':'Manual review'}
