        import re
from core.logger import logger

def extract_from_text(text: str):
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    out = {'invoice_id': None, 'vendor_name': None, 'po_number': None, 'amount': None, 'invoice_date': None}
    for l in lines:
        low = l.lower()
        if low.startswith('invoice:') or low.startswith('invoice id:'):
            out['invoice_id'] = l.split(':',1)[1].strip()
        elif low.startswith('vendor:'):
            out['vendor_name'] = l.split(':',1)[1].strip()
        elif 'po' in low and ':' in l:
            out['po_number'] = l.split(':',1)[1].strip()
        elif 'amount' in low:
            s = ''.join(ch for ch in l if (ch.isdigit() or ch in '.,'))
            try:
                out['amount'] = float(s.replace(',',''))
            except:
                out['amount'] = None
        elif 'date' in low:
            tokens = l.split()
            for t in tokens:
                if '-' in t or '/' in t:
                    out['invoice_date'] = t
    logger.info('Extracted: %s', out)
    return out
