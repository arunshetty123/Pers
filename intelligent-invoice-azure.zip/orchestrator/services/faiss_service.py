        import os
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from core.config import settings

class FaissService:
    def __init__(self):
        self.path = settings.VECTORSTORE_PATH
        self.emb = OpenAIEmbeddings(openai_api_key=settings.AZURE_OPENAI_API_KEY)

    def retrieve(self, query, k=3):
        if not os.path.exists(self.path):
            return ''
        db = FAISS.load_local(self.path, self.emb, allow_dangerous_deserialization=True)
        docs = db.similarity_search(query, k=k)
        return '\n'.join([d.page_content for d in docs])
