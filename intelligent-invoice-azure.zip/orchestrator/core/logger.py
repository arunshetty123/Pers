        from loguru import logger
import os, sys
os.makedirs('logs', exist_ok=True)
logger.remove()
logger.add(sys.stderr, level='INFO', format='{time:HH:mm:ss} | {level} | {message}')
logger.add('logs/orchestrator.log', rotation='5 MB')
