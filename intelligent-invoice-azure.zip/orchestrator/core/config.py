        import os
from dotenv import load_dotenv
load_dotenv()

class Settings:
    AZURE_OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT','')
    AZURE_OPENAI_API_KEY = os.getenv('AZURE_OPENAI_API_KEY','')
    AZURE_OPENAI_DEPLOYMENT = os.getenv('AZURE_OPENAI_DEPLOYMENT','')
    VECTORSTORE_PATH = os.getenv('VECTORSTORE_PATH','vectorstore/faiss_index')
    POLICY_DIR = os.getenv('POLICY_DIR','data/policies')
    HOST = os.getenv('HOST','0.0.0.0')
    PORT = int(os.getenv('PORT','8001'))

settings = Settings()
