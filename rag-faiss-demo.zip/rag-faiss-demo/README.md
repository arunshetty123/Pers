# RAG FAISS Demo
This project demonstrates a RAG pipeline with FAISS and FastAPI.