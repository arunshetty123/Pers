# Code to query RAG system
pass