USE_AZURE = False
LLM_DEPLOYMENT = ''
INDEX_DIR = './faiss_index'