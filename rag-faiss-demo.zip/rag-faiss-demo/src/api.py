from fastapi import FastAPI
from pydantic import BaseModel
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langchain.vectorstores import FAISS
from langchain_core.prompts import PromptTemplate
from src.config import USE_AZURE, LLM_DEPLOYMENT, INDEX_DIR
import os

app = FastAPI(title="RAG FAISS API", description="RAG pipeline powered by LangChain + FAISS", version="1.0")

# Initialize once at startup
vectorstore = None
retriever = None
llm = None

class QueryRequest(BaseModel):
    question: str

def get_llm():
    if USE_AZURE:
        return AzureChatOpenAI(azure_deployment=LLM_DEPLOYMENT)
    else:
        return ChatOpenAI(model_name="gpt-4o", temperature=0)

@app.on_event("startup")
def load_resources():
    global vectorstore, retriever, llm
    if not os.path.exists(INDEX_DIR):
        raise RuntimeError(f"FAISS index not found at {INDEX_DIR}. Run ingest_data.py first.")
    vectorstore = FAISS.load_local(INDEX_DIR, embeddings=None, allow_dangerous_deserialization=True)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 3})
    llm = get_llm()
    print("✅ RAG API ready!")

@app.post("/query")
def query_rag(request: QueryRequest):
    question = request.question
    docs = retriever.get_relevant_documents(question)
    context = "\n---\n".join([d.page_content for d in docs])
    prompt = PromptTemplate(
        template="""You are a helpful assistant. Use the provided context to answer.
Context:
{context}
Question:
{question}
"""",
        input_variables=["context", "question"]
    )
    final_prompt = prompt.format(context=context, question=question)
    resp = llm.invoke(final_prompt)
    return {
        "question": question,
        "answer": resp.content if hasattr(resp, 'content') else str(resp),
        "sources": [d.metadata.get("source") for d in docs]
    }

@app.get("/")
def home():
    return {"message": "Welcome to the RAG FAISS API. Use POST /query with a question."}
