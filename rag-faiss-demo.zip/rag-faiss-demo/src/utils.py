# Utility functions
pass