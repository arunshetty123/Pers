import pandas as pd
from core.config import settings
from core.logger import logger

class VendorService:
    def __init__(self):
        self.df = pd.read_csv(settings.VENDOR_MASTER)

    def validate_vendor(self, vendor_name, po_number, amount):
        issues = []
        if vendor_name is None or po_number is None:
            issues.append('Missing vendor or PO information.')
            return issues
        match = self.df[
            (self.df['vendor_name'].str.lower() == str(vendor_name).lower()) &
            (self.df['po_number'].str.upper() == str(po_number).upper())
        ]
        if match.empty:
            issues.append('Vendor or PO not found in master data.')
        else:
            max_amt = float(match.iloc[0]['max_amount'])
            if amount is not None and amount > max_amt:
                issues.append(f'Invoice amount exceeds approved limit ({max_amt}).')
            if str(match.iloc[0].get('sensitive','False')).lower() == 'true':
                issues.append('Vendor marked sensitive — check KYC docs.')
        return issues
