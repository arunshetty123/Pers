from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from core.config import settings
import os
def build_faiss_index():
    print('Building FAISS index from', settings.POLICY_FILE)
    with open(settings.POLICY_FILE, 'r') as f:
        text = f.read()
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    chunks = splitter.split_text(text)
    docs = [Document(page_content=c) for c in chunks]
    embeddings = OpenAIEmbeddings(openai_api_key=settings.OPENAI_API_KEY)
    db = FAISS.from_documents(docs, embeddings)
    os.makedirs(os.path.dirname(settings.VECTORSTORE_PATH), exist_ok=True)
    db.save_local(settings.VECTORSTORE_PATH)
    print('Saved FAISS index to', settings.VECTORSTORE_PATH)

if __name__ == '__main__':
    build_faiss_index()
