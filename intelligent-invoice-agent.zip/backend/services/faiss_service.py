from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from core.config import settings
from core.logger import logger
import os

class FAISSService:
    def __init__(self):
        pass

    def build_index(self):
        from services.build_faiss_index import build_faiss_index
        build_faiss_index()

    def retrieve(self, query: str, k: int = 3):
        embeddings = OpenAIEmbeddings(openai_api_key=settings.OPENAI_API_KEY)
        if not os.path.exists(settings.VECTORSTORE_PATH):
            logger.warning("Vectorstore not found, building index...")
            self.build_index()
        db = FAISS.load_local(settings.VECTORSTORE_PATH, embeddings, allow_dangerous_deserialization=True)
        docs = db.similarity_search(query, k=k)
        return '\n'.join([d.page_content for d in docs])
