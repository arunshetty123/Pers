# Intelligent Invoice Agent - Backend (Agentic Graph)

## Overview
Modular FastAPI backend demonstrating a LangGraph-style multi-step reasoning graph
for invoice validation. This prototype includes:
- Graph engine (nodes + executor)
- Nodes: OCR (text), Extract, RAG (FAISS), Rule Validation, LLM Reasoner, Decision
- Services: FAISS builder/retriever, Vendor service
- Simple ReasoningAgent wrapper for OpenAI
- Example endpoint: /validate_invoice_graph

## Setup (local)
1. Copy `.env.example` to `.env` and add your OPENAI_API_KEY.
2. Install dependencies:
   ```
   python -m pip install -r requirements.txt
   ```
3. (Optional) Build FAISS index:
   ```
   python -m backend.services.build_faiss_index
   ```
4. Run server:
   ```
   uvicorn backend.app:app --reload
   ```

## Test (quick)
```
curl -X POST "http://127.0.0.1:8000/validate_invoice_graph" \
  -H "Content-Type: application/json" \
  -d '{
    "sample_invoice_text": "Invoice: INV-2025-001\nVendor: ABC Supplies\nPO: PO123\nAmount: 12,000\nDate: 2025-04-01"
  }'
```
