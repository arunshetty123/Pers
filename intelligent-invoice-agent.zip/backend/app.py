from fastapi import FastAPI
from pydantic import BaseModel
from agents.graph_orchestrator import process_invoice_with_graph
from core.logger import logger

app = FastAPI(title='Agentic Invoice Agent - Graph')

class InvoicePayload(BaseModel):
    invoice_path: str = None
    sample_invoice_text: str = None

@app.get('/')
def root():
    return {'message': 'Agentic Invoice Agent (Graph) is running 🚀'}

@app.post('/validate_invoice_graph')
def validate_invoice_graph(payload: InvoicePayload):
    initial = payload.dict()
    logger.info('Starting graph-based validation')
    result_context = process_invoice_with_graph(initial)
    return {
        'invoice_id': result_context.get('invoice_id'),
        'final_status': result_context.get('final_status'),
        'issues': result_context.get('issues'),
        'ai_reasoning': result_context.get('ai_reasoning'),
        'policies_context': result_context.get('policies_context')
    }
