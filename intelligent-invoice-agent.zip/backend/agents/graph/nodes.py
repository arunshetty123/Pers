from typing import Dict
from core.logger import logger
from core.utils import safe_float
from services.faiss_service import FAISSService
from services.vendor_service import VendorService
from agents.reasoning_agent import ReasoningAgent
import os

faiss = FAISSService()
vendor_svc = VendorService()
reasoner = ReasoningAgent()

def ocr_node(context: Dict):
    invoice_path = context.get('invoice_path')
    if invoice_path and os.path.exists(invoice_path):
        # simple: support .txt as sample; in prod use OCR APIs
        if invoice_path.endswith('.txt'):
            with open(invoice_path, 'r') as f:
                text = f.read()
        else:
            text = context.get('sample_invoice_text','')
    else:
        text = context.get('sample_invoice_text','')
    logger.info(f"[ocr_node] extracted {len(text)} chars")
    return {'ocr_text': text}

def extract_node(context: Dict):
    text = context.get('ocr_text','')
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    vendor = None; po = None; amount = None; invoice_id = None; date = None
    for l in lines:
        low = l.lower()
        if low.startswith('vendor:'):
            vendor = l.split(':',1)[1].strip()
        if 'po' in low and ':' in l.lower():
            if ':' in l:
                po = l.split(':',1)[1].strip()
        if 'amount' in low:
            amt = ''.join(ch for ch in l if (ch.isdigit() or ch in '.,'))
            try:
                amount = float(amt.replace(',',''))
            except:
                amount = None
        if low.startswith('invoice:') or low.startswith('invoice id:'):
            invoice_id = l.split(':',1)[1].strip()
        if 'date' in low:
            tokens = l.split()
            for t in tokens:
                if '/' in t or '-' in t:
                    date = t
    logger.info(f"[extract_node] vendor={vendor}, po={po}, amount={amount}")
    return {
        'vendor_name': vendor,
        'po_number': po,
        'amount': safe_float(amount),
        'invoice_id': invoice_id,
        'invoice_date': date
    }

def rag_node(context: Dict):
    vendor = context.get('vendor_name')
    po = context.get('po_number')
    q = f"invoice validation rules for vendor {vendor} and po {po}"
    policies = faiss.retrieve(q)
    return {'policies_context': policies}

def rule_validation_node(context: Dict):
    invoice = {
        'vendor_name': context.get('vendor_name'),
        'po_number': context.get('po_number'),
        'amount': context.get('amount'),
        'invoice_id': context.get('invoice_id')
    }
    issues = vendor_svc.validate_vendor(invoice['vendor_name'], invoice['po_number'], invoice['amount'])
    return {'issues': issues}

def llm_reasoner_node(context: Dict):
    invoice = {
        'vendor_name': context.get('vendor_name'),
        'po_number': context.get('po_number'),
        'amount': context.get('amount'),
        'invoice_id': context.get('invoice_id'),
        'invoice_date': context.get('invoice_date')
    }
    issues = context.get('issues', [])
    policies = context.get('policies_context', '')
    reasoning_json = reasoner.analyze(invoice, issues, policies)
    return {'ai_reasoning': reasoning_json}

def decision_node(context: Dict):
    reasoning = context.get('ai_reasoning', {})
    status = 'Needs Review'
    if isinstance(reasoning, dict):
        status = reasoning.get('status', status)
    else:
        rlow = str(reasoning).lower()
        if 'valid' in rlow and 'needs' not in rlow:
            status = 'Valid'
        elif 'reject' in rlow:
            status = 'Rejected'
    return {'final_status': status}
