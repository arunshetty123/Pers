from typing import List, Dict, Callable
import time
from core.logger import logger

class Node:
    def __init__(self, name: str, run_fn: Callable[[Dict], Dict], inputs: List[str]=None, outputs: List[str]=None):
        self.name = name
        self.run_fn = run_fn
        self.inputs = inputs or []
        self.outputs = outputs or []

    def run(self, context: Dict):
        logger.info(f"[Node:{self.name}] start")
        start = time.time()
        result = self.run_fn(context) or {}
        for k, v in result.items():
            context[k] = v
        duration = time.time() - start
        logger.info(f"[Node:{self.name}] done ({duration:.2f}s)")
        return result

class GraphExecutor:
    def __init__(self, nodes: List[Node], edges: List[tuple]):
        self.nodes = {n.name: n for n in nodes}
        self.edges = edges
        self.order = self._topological_order()

    def _topological_order(self):
        indeg = {name: 0 for name in self.nodes}
        adj = {name: [] for name in self.nodes}
        for a,b in self.edges:
            adj[a].append(b)
            indeg[b] += 1
        q = [n for n,d in indeg.items() if d==0]
        order = []
        while q:
            n = q.pop(0)
            order.append(n)
            for m in adj[n]:
                indeg[m] -= 1
                if indeg[m] == 0:
                    q.append(m)
        if len(order) != len(self.nodes):
            raise ValueError("Graph has cycles or disconnected components")
        return order

    def run(self, initial_context: Dict):
        context = dict(initial_context)
        logger.info("Graph start")
        for node_name in self.order:
            node = self.nodes[node_name]
            node.run(context)
        logger.info("Graph finished")
        return context
