from services.faiss_service import FAISSService

class RAGAgent:
    def __init__(self):
        self.faiss = FAISSService()

    def fetch_policies(self, query: str):
        return self.faiss.retrieve(query)
