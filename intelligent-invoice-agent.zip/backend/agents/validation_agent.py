from services.vendor_service import VendorService

class ValidationAgent:
    def __init__(self):
        self.vendor_service = VendorService()

    def run_checks(self, invoice: dict):
        return self.vendor_service.validate_vendor(
            vendor_name=invoice.get('vendor_name'),
            po_number=invoice.get('po_number'),
            amount=invoice.get('amount')
        )
