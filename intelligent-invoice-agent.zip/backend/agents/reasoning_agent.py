import json
from openai import OpenAI
from core.config import settings
from core.logger import logger

class ReasoningAgent:
    def __init__(self):
        # Uses openai-python-sdk style (v1-like). If you use openai package, adjust accordingly.
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)

    def analyze(self, invoice: dict, issues: list, policies: str):
        prompt = f"""You are an invoice reasoning assistant. Given invoice details, validation issues, and company policies,
return a JSON object with keys:
- status: one of [Valid, Needs Review, Rejected]
- reasoning: short explanation (single paragraph)
- suggested_action: next action to take (string)

Invoice:
{invoice}

Validation Issues:
{issues}

Relevant Policies:
{policies}
"""

        try:
            resp = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role":"user","content":prompt}],
                temperature=0.0,
                max_tokens=400
            )
            content = resp.choices[0].message.content
        except Exception as e:
            logger.error(f'ReasoningAgent LLM call failed: {e}')
            content = json.dumps({
                'status': 'Needs Review',
                'reasoning': 'LLM unavailable — fallback to manual review.',
                'suggested_action': 'Manual review'
            })
        # try parse JSON
        try:
            parsed = json.loads(content)
            return parsed
        except Exception:
            # simplistic wrap if LLM returned text
            return {
                'status': 'Needs Review',
                'reasoning': str(content)[:800],
                'suggested_action': 'Manual review'
            }
