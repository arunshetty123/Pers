from agents.graph.engine import Node, GraphExecutor
from agents.graph.nodes import (
    ocr_node, extract_node, rag_node,
    rule_validation_node, llm_reasoner_node,
    decision_node
)
from core.logger import logger

def build_invoice_graph():
    nodes = [
        Node('OCR', ocr_node, inputs=['invoice_path'], outputs=['ocr_text']),
        Node('EXTRACT', extract_node, inputs=['ocr_text'], outputs=['vendor_name','po_number','amount','invoice_id','invoice_date']),
        Node('RAG', rag_node, inputs=['vendor_name','po_number'], outputs=['policies_context']),
        Node('RULE_VALIDATION', rule_validation_node, inputs=['vendor_name','po_number','amount'], outputs=['issues']),
        Node('LLM_REASONER', llm_reasoner_node, inputs=['vendor_name','po_number','amount','issues','policies_context'], outputs=['ai_reasoning']),
        Node('DECISION', decision_node, inputs=['ai_reasoning','issues'], outputs=['final_status'])
    ]
    edges = [
        ('OCR','EXTRACT'),
        ('EXTRACT','RAG'),
        ('EXTRACT','RULE_VALIDATION'),
        ('RAG','LLM_REASONER'),
        ('RULE_VALIDATION','LLM_REASONER'),
        ('LLM_REASONER','DECISION')
    ]
    return GraphExecutor(nodes, edges)

def process_invoice_with_graph(initial_context: dict):
    executor = build_invoice_graph()
    context = executor.run(initial_context)
    logger.info(f"Graph result: status={context.get('final_status')}, issues={context.get('issues')}")
    return context
