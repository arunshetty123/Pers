import re
def safe_float(val):
    if val is None:
        return None
    if isinstance(val, (int,float)):
        return float(val)
    s = str(val)
    s = re.sub(r'[^0-9.]', '', s)
    try:
        return float(s)
    except:
        return None
