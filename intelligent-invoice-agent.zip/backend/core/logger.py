from loguru import logger
import sys, os
os.makedirs('logs', exist_ok=True)
logger.remove()
logger.add(sys.stderr, colorize=True, format="<green>{time}</green> | <level>{level}</level> | <level>{message}</level>")
logger.add("logs/invoice_agent.log", rotation="1 MB")
