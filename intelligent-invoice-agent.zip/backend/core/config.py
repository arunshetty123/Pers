import os
from dotenv import load_dotenv
load_dotenv()

class Settings:
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    VECTORSTORE_PATH: str = os.getenv("VECTORSTORE_PATH", "vectorstore/faiss_index")
    POLICY_FILE: str = os.getenv("POLICY_FILE", "data/policies.txt")
    VENDOR_MASTER: str = os.getenv("VENDOR_MASTER", "data/vendor_master.csv")

settings = Settings()
