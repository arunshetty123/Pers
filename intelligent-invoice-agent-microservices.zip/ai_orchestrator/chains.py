from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o-mini")

extract_prompt = PromptTemplate.from_template(
    "Extract invoice fields from the document: {invoice_text}"
)
validate_prompt = PromptTemplate.from_template(
    "Validate extracted fields against company policy: {fields}"
)
reason_prompt = PromptTemplate.from_template(
    "Provide reasoning and compliance result for: {validated_data}"
)

extract_chain = LLMChain(llm=llm, prompt=extract_prompt)
validate_chain = LLMChain(llm=llm, prompt=validate_prompt)
reasoning_chain = LLMChain(llm=llm, prompt=reason_prompt)
