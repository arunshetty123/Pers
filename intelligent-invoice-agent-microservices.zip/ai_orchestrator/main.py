from fastapi import FastAPI
from graph import build_invoice_graph

app = FastAPI(title="AI Orchestrator Service")

@app.post("/process_invoice")
async def process_invoice(invoice_data: dict):
    graph = build_invoice_graph()
    result = await graph.invoke(invoice_data)
    return {"status": "success", "result": result}
