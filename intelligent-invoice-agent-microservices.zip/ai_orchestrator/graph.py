from langgraph.graph import StateGraph
from chains import extract_chain, validate_chain, reasoning_chain

def build_invoice_graph():
    graph = StateGraph()
    graph.add_node("extract", extract_chain)
    graph.add_node("validate", validate_chain)
    graph.add_node("reason", reasoning_chain)

    graph.add_edge("extract", "validate")
    graph.add_edge("validate", "reason")
    graph.set_entry_point("extract")

    return graph.compile()
