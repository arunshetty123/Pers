from fastapi import FastAPI, UploadFile
import requests

app = FastAPI(title="Invoice API Service")

AI_ORCHESTRATOR_URL = "http://localhost:8001/process_invoice"

@app.post("/upload_invoice")
async def upload_invoice(file: UploadFile):
    text = await file.read()
    response = requests.post(AI_ORCHESTRATOR_URL, json={"invoice_text": text.decode()})
    return response.json()
