import requests

def trigger_invoice_upload(file_path):
    with open(file_path, 'rb') as f:
        response = requests.post('http://localhost:8000/upload_invoice', files={'file': f})
    print(response.json())
