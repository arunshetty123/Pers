# Intelligent Invoice Agent (LangGraph + LangChain + UiPath)

This project demonstrates the integration of Agentic AI (LangGraph) and RPA (UiPath) for automated invoice processing.

## Microservices
1. **invoice_api** – Receives and uploads invoices
2. **ai_orchestrator** – Handles reasoning and validation using LangGraph
3. **uipath_connector** – Triggers and integrates UiPath workflows
