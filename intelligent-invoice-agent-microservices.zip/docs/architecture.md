# Architecture Overview

UiPath → Invoice API → AI Orchestrator (LangGraph) → Validation/Reasoning → ERP Update

Mermaid Diagram:
```mermaid
flowchart TD
A[UiPath Bot] --> B[Invoice API Service]
B --> C[AI Orchestrator (LangGraph)]
C --> D[RAG + Validation Chains]
D --> E[ERP / Database Update]
```
