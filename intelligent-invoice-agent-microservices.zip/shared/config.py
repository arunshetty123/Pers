# config.py placeholder for shared
