from fastapi import FastAPI, UploadFile, File, Form
import requests, os
from core.config import settings
from core.logger import logger

app = FastAPI(title='Gateway')

@app.post('/submit_invoice')
async def submit_invoice(invoice_text: str = Form(None), file: UploadFile = File(None)):
    os.makedirs(settings.STORAGE_DIR, exist_ok=True)
    path = None
    if file:
        path = os.path.join(settings.STORAGE_DIR, file.filename)
        with open(path, 'wb') as f:
            f.write(await file.read())
    payload = {'invoice_text': invoice_text, 'invoice_path': path}
    resp = requests.post(settings.ORCH_URL, json=payload, timeout=60)
    return resp.json()

@app.get('/')
def root():
    return {'message':'Gateway running'}
