import os
from dotenv import load_dotenv
load_dotenv()
class Settings:
    ORCH_URL = os.getenv('ORCH_URL','http://localhost:8001/process_invoice')
    STORAGE_DIR = os.getenv('STORAGE_DIR','invoices')
    HOST = os.getenv('HOST','0.0.0.0')
    PORT = int(os.getenv('PORT','8000'))
settings = Settings()
