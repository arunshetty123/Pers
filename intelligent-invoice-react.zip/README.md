# Intelligent Invoice Agent (ReAct-style Agent) - Azure OpenAI Edition

This project contains two services:
- orchestrator/: LangGraph-like orchestrator using LangChain, FAISS, and an Agent (ReAct-style)
- gateway/: FastAPI gateway for UiPath/RPA

Key features:
- Extractor implemented as an LLM structured extractor (PydanticOutputParser)
- RAG retrieval using FAISS and OpenAIEmbeddings (Azure OpenAI credentials supported)
- ReAct-style LangChain Agent that can call RAGTool and ValidatorTool during reasoning
- LangGraph-like engine to orchestrate nodes in an auditable graph

See each service README for setup and run instructions.
