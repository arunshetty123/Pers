from typing import Callable, List, Dict
import time
from core.logger import logger

class Node:
    def __init__(self, name: str, run_fn: Callable[[Dict], Dict]):
        self.name = name
        self.run_fn = run_fn
    def run(self, context: Dict):
        logger.info(f'[Node:{self.name}] start')
        start = time.time()
        res = self.run_fn(context) or {}
        context.update(res)
        logger.info(f'[Node:{self.name}] done in {time.time()-start:.2f}s')
        return res

class GraphExecutor:
    def __init__(self, nodes: List[Node], edges: List[tuple]):
        self.nodes = {n.name: n for n in nodes}
        self.edges = edges
        self.order = self._topo_order()
    def _topo_order(self):
        indeg = {k:0 for k in self.nodes}
        adj = {k:[] for k in self.nodes}
        for a,b in self.edges:
            adj[a].append(b); indeg[b]+=1
        q = [n for n,d in indeg.items() if d==0]; order=[]
        while q:
            n=q.pop(0); order.append(n)
            for m in adj[n]:
                indeg[m]-=1
                if indeg[m]==0: q.append(m)
        if len(order)!=len(self.nodes): raise ValueError('Graph invalid (cycle?)')
        return order
    def run(self, initial: Dict):
        ctx = dict(initial)
        logger.info('Graph start')
        for name in self.order:
            self.nodes[name].run(ctx)
        logger.info('Graph finished')
        return ctx
