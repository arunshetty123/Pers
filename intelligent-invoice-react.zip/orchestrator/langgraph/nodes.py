from typing import Dict
from core.logger import logger
from agents.extractor import Extractor, InvoiceSchema
from agents.rag_tool import RAGTool
from agents.validator_tool import ValidatorTool
from agents.reasoner_agent import ReasonerAgent
from services.faiss_service import FaissService

extractor = Extractor()
rag = RAGTool()
validator_tool = ValidatorTool()
reasoner = ReasonerAgent()
faiss = FaissService()

def ocr_node(ctx: Dict):
    text = ctx.get('invoice_text','')
    if not text and ctx.get('invoice_path'):
        try:
            with open(ctx['invoice_path'],'r',encoding='utf-8') as f:
                text = f.read()
        except:
            text = ''
    return {'ocr_text': text}

def extract_node(ctx: Dict):
    t = ctx.get('ocr_text','')
    extracted = extractor.extract_structured(t)
    return {'extracted': extracted}

def rag_node(ctx: Dict):
    q = f"validation rules for vendor {ctx.get('extracted',{}).get('vendor_name')} and po {ctx.get('extracted',{}).get('po_number')}"
    policies = faiss.retrieve(q)
    return {'policies_context': policies}

def validation_node(ctx: Dict):
    issues = validator_tool._run(ctx.get('extracted', {}))
    return {'issues': issues}

def reasoner_node(ctx: Dict):
    ex = ctx.get('extracted', {})
    policies = ctx.get('policies_context','')
    ai = reasoner.reason(ex, policies)
    return {'ai_reasoning': ai}

def decision_node(ctx: Dict):
    ar = ctx.get('ai_reasoning', {})
    status = ar.get('status') if isinstance(ar, dict) else 'Needs Review'
    return {'final_status': status}
