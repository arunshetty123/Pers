from langchain.tools import BaseTool
from services.faiss_service import FaissService

class RAGTool(BaseTool):
    name = 'retrieve_policies'
    description = 'Retrieve relevant policy snippets given a short query.'
    def __init__(self):
        self.fs = FaissService()
    def _run(self, query: str):
        return self.fs.retrieve(query, k=4)
    async def _arun(self, query: str):
        return self._run(query)
