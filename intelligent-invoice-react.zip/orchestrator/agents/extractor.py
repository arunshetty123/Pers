from pydantic import BaseModel, Field
from langchain.output_parsers import PydanticOutputParser
from langchain.chat_models import AzureChatOpenAI
from langchain.schema import HumanMessage
from core.config import settings
from core.logger import logger

class InvoiceSchema(BaseModel):
    invoice_id: str = Field(None, description='Invoice identifier')
    vendor_name: str = Field(None, description='Vendor name')
    po_number: str = Field(None, description='Purchase order number')
    amount: float = Field(None, description='Invoice amount')
    invoice_date: str = Field(None, description='Invoice date, YYYY-MM-DD')
    tax: float = Field(None, description='Tax amount if available')

parser = PydanticOutputParser(pydantic_object=InvoiceSchema)

class Extractor:
    def __init__(self, deployment=None):
        self.deployment = deployment or settings.AZURE_OPENAI_DEPLOYMENT
        # AzureChatOpenAI via LangChain
        self.llm = AzureChatOpenAI(deployment_name=self.deployment, openai_api_base=settings.AZURE_OPENAI_ENDPOINT, openai_api_key=settings.AZURE_OPENAI_API_KEY, temperature=0.0)

    def extract_structured(self, text: str):
        prompt = f"""Extract the following invoice fields from the provided text and return ONLY valid JSON conforming to the schema: {parser.get_format_instructions()}

Text:
{text}
"""
        try:
            resp = self.llm([HumanMessage(content=prompt)])
            content = resp.content
            parsed = parser.parse(content)
            logger.info('Extractor parsed: %s', parsed.json())
            return parsed.dict()
        except Exception as e:
            logger.error('Extractor LLM failed: %s', e)
            return {}
