    import json
    from langchain.agents import initialize_agent, AgentType, Tool
    from langchain.chat_models import AzureChatOpenAI
    from core.config import settings
    from core.logger import logger
    from agents.rag_tool import RAGTool
    from agents.validator_tool import ValidatorTool

    class ReasonerAgent:
        def __init__(self, deployment=None):
            self.deployment = deployment or settings.AZURE_OPENAI_DEPLOYMENT
            self.llm = AzureChatOpenAI(deployment_name=self.deployment, openai_api_base=settings.AZURE_OPENAI_ENDPOINT, openai_api_key=settings.AZURE_OPENAI_API_KEY, temperature=0.0)
            # instantiate tools and wrap as LangChain Tool objects if needed
            self.rag = RAGTool()
            self.validator = ValidatorTool()
            # convert to Tool wrappers compatible with initialize_agent
            self.tools = [
                Tool.from_function(self.rag._run, name='retrieve_policies', description=self.rag.description),
                Tool.from_function(self.validator._run, name='validator_tool', description=self.validator.description)
            ]
            # initialize ReAct-style agent
            self.agent = initialize_agent(self.tools, self.llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, verbose=False)

        def reason(self, extracted: dict, policies_context: str):
            # Provide context and ask agent to produce JSON with status, reasoning, suggested_action
            prompt_input = f"""You are an invoice reasoning agent. Use the extracted fields and possibly call tools:
    - retrieve_policies(query) returns policy snippets
    - validator_tool(payload) returns a list of validation issues

    Extracted fields: {extracted}
    Retrieved policies context: {policies_context}

    Decide whether invoice is Valid / Needs Review / Rejected. Provide final output as STRICT JSON with keys: status, reasoning, suggested_action, and include any 'tool_calls' list showing tool outputs used.
"""
            try:
                result = self.agent.run(prompt_input)
                # attempt to parse JSON from result (agent may return text)
                try:
                    parsed = json.loads(result)
                    return parsed
                except Exception:
                    # wrap textual result
                    return {'status':'Needs Review','reasoning': result[:800], 'suggested_action':'Manual review'}
            except Exception as e:
                logger.error('Agent run failed: %s', e)
                return {'status':'Needs Review','reasoning':'Agent failure','suggested_action':'Manual review'}
