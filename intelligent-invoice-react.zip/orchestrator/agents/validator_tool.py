from langchain.tools import BaseTool
import pandas as pd
from core.config import settings

class ValidatorTool(BaseTool):
    name = 'validator_tool'
    description = 'Validate invoice fields against vendor master and simple rules; returns list of issues.'
    def __init__(self):
        self.df = pd.read_csv(settings.VENDOR_CSV)

    def _run(self, payload: dict):
        # expects payload dict with vendor_name, po_number, amount
        vendor = payload.get('vendor_name'); po = payload.get('po_number'); amount = payload.get('amount')
        issues = []
        if not vendor or not po:
            issues.append('Missing vendor or PO.')
            return issues
        match = self.df[(self.df['vendor_name'].str.lower() == str(vendor).lower()) & (self.df['po_number'].str.upper() == str(po).upper())]
        if match.empty:
            issues.append('Vendor/PO not found in vendor master.')
        else:
            cap = float(match.iloc[0]['max_amount'])
            if amount is not None and amount > cap:
                issues.append(f'Amount {amount} exceeds cap {cap}.')
            if str(match.iloc[0].get('sensitive', False)).lower() in ('true','1','yes'):
                issues.append('Vendor marked sensitive — KYC required.')
        return issues

    async def _arun(self, payload: dict):
        return self._run(payload)
