import os
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.docstore.document import Document
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from core.config import settings

def build_index():
    files = []
    if not os.path.exists(settings.POLICY_DIR):
        print('Policy dir not found:', settings.POLICY_DIR); return
    for fn in os.listdir(settings.POLICY_DIR):
        if fn.lower().endswith('.txt'):
            with open(os.path.join(settings.POLICY_DIR, fn), 'r', encoding='utf-8') as f:
                files.append(f.read())
    combined = '\n\n'.join(files)
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    chunks = splitter.split_text(combined)
    docs = [Document(page_content=c) for c in chunks]
    embeddings = OpenAIEmbeddings(openai_api_key=settings.AZURE_OPENAI_API_KEY)
    db = FAISS.from_documents(docs, embeddings)
    os.makedirs(os.path.dirname(settings.VECTORSTORE_PATH), exist_ok=True)
    db.save_local(settings.VECTORSTORE_PATH)
    print('FAISS index saved to', settings.VECTORSTORE_PATH)

if __name__ == '__main__':
    build_index()
